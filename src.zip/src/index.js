// import "bootstrap/dist/css/bootstrap.min.css";
// import React from 'react';
// import ReactDOM from 'react-dom';
//  import { Provider } from "react-redux";
// import { BrowserRouter as Router } from "react-router-dom";
// import App from "./components/App";
// import { history } from "./components/login/history";
// import { store } from "./components/login/_reducers/store";


// ReactDOM.render(
//   <Router history={history}>
//     <Provider store={store}>
//       <App />
//     </Provider>
//   </Router>,
//   document.getElementById("root")
// );
// import "bootstrap/dist/css/bootstrap.min.css";
// import React from "react";
// import ReactDOM from "react-dom";
// import { Provider } from "react-redux";
// import { BrowserRouter as Router } from "react-router-dom";
// import App from "./components/App";
// import { history } from "./components/login/history";
// import { store } from "./components/login/_reducers/store";
// import TransactionReducer from './components/transaction/reducers/transactionreducer'
// import OrderReducer from './components/transaction/reducers/orderReducer'
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './components/App';
import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter } from 'react-router-dom';
import ReduxThunk from 'redux-thunk';
import { Provider } from 'react-redux';
import {combineReducers,  createStore, applyMiddleware, compose } from 'redux';
//import 'mdbreact/dist/css/mdb.css';
//import { MDBTimePicker, MDBCol } from "mdbreact";
import TransactionReducer from './components/transaction/reducers/transactionreducer'
 import OrderReducer from './components/transaction/reducers/orderReducer'


let allReducers = combineReducers({'TransactionReducer': TransactionReducer, 'OrderReducer': OrderReducer});
let store = createStore(allReducers,applyMiddleware(ReduxThunk));
store.subscribe(()=>console.log('Store state: ' ,store.getState()));

store.subscribe(()=>console.log('Current State: ', store.getState()));

ReactDOM.render(
  <React.StrictMode>
    <BrowserRouter>
    <Provider store={store}>
      <App />
      </Provider>
    </BrowserRouter>
  </React.StrictMode>,
  document.getElementById('root')
);

reportWebVitals();
