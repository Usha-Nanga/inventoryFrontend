import React from 'react';
class invalidLogin extends React.Component{
    render(){
        return(
            <h1>Invalid</h1>
        );
    }
}
export default invalidLogin;