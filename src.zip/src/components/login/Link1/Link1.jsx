import {Link} from "react-router-dom"
import React from 'react'
import {Button} from 'react-bootstrap'
import './styles.css'
import 'bootstrap/dist/css/bootstrap.min.css';
class Link1 extends React.Component{
    render(){
        return(
            <div className='l1'>
            <div className='Links'>
&nbsp;&nbsp;&nbsp;
<Link to='/login'><Button >Login</Button></Link>

</div>
</div>
        );
    }
}
export default Link1;