import React from "react";
import Header from "../common/Header";
import "./LoginPage.css";

class LoginPage extends React.Component {
  render() {
    return (
      <>
        <Header />
        <div></div>
        <div>
                <div>
                <img src="https://www.vmedulife.com/webassets/images/inventory-management-software.png" height="100%" width="100%"  vspace="10" alt="summer cool"></img>
                </div>
                {/* <div>
                    <span><img src="https://visme.co/blog/wp-content/uploads/2020/02/3-Fashion-Design-Animated-Presentation-Template-2.gif" height="100%" width="100%" vspace="10" alt="summer cool"></img></span>
                
                </div> */}
                
                
                
                </div>
           
      </>
    );
  }
}
export default LoginPage;
