import React, { Component } from 'react'

class HeaderLogin extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 
        }
    }

    render() {
        return (
            <div>
                <header className = "footer">
                    <span className="text-muted">Inventory Management</span>
                </header>
            </div>
        )
    }
}

export default HeaderLogin