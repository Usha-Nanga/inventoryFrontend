import './styles.css'
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import {history} from '../history'
import LoginService from '../Service/LoginService'
import {toast} from 'react-toastify'
// import HeaderLogin from './HeaderLogin';
toast.configure();
class Login extends React.Component{
    constructor(props){
        super(props);
    this.state={
        userId:'',
        password:'',
        show:false,
    }
    this.handlesubmit=this.handlesubmit.bind(this);
};
    handleSetuser=e=>{
       
        this.setState({userId:(e.target.value)})
    }
    handleSetpassword=e=>
    {
       
        this.setState({password:(e.target.value)})
    }
    handlesubmit=()=>{
        var id=this.state.userId;
        var password=this.state.password;
        console.log(id,password);
        this.setState({show:true});
      /*  if(id&&password)
        {
            this.props.login(id,password);
        }*/
        LoginService.validate(id, password)
        .then(
            user => { 
//console.log(user.response.ok);
                console.log(user.data)
                console.log(user.status)
                console.log(user.data.type)
                if(user.data==='sucess login'){
                toast.success("login successfull",{position:toast.POSITION.TOP_CENTER,autoClose:false})
               history.push({pathname:'/home',state:{data:user.data.type}});
                }else{
                    toast.error("Something Went Wrong",{position:toast.POSITION.TOP_CENTER,autoClose:false})
                }
              
               /*if(user.status===200){
                 if(user.data.type==='customer' || user.data.type==='Admin')
                {
               
                toast.success("login successfull",{position:toast.POSITION.TOP_CENTER,autoClose:false})
               history.push({pathname:'/home',state:{data:user.data.type}});
                }
                }
            else
                {
          
                   
                    toast.error("Enter Valid userId and password",{position:toast.POSITION.TOP_CENTER,autoClose:false})
                    //history.push({pathname:'/login',state:{data1:user.data}});
                 }*/
    },
            
        ).catch(res=>{
            toast.error("Enter Valid userId and password",{position:toast.POSITION.TOP_CENTER,autoClose:false})
           // history.push({pathname:'/login',state:{data1:user.data}});  
        });

   
       

    };
      register=()=>{
          this.props.history.push("/register");
      }

   
    render(){
        const{loggingIn}=this.props;
     //const{alertActions}=this.props;
        const{userId,password,show}=this.state;

       
        return(
        //    <>
        //    <HeaderLogin/>
          <div>
        <img src="https://www.chlsoftech.com/Content/product-eZ/images/inventory-banner.jpg" height="100%" width="100%" vspace="60" alt="summer cool"></img>
                
                <div className='user-id1'>
             
                <div className='data'>
                    
                <h4 style={{textAlign: 'center', color: 'white'}}> Admin Login</h4>
                
    </div>
                <form name='login'  >
               <b><hr></hr></b>
              <div className={'form-group'+ (show && !userId ? 'has-error': '')}>
            <label  htmlFor='userId'><h5 style={{textAlign: 'center', color: 'white'}}><b>UserId:</b></h5> </label>   <br></br><input type='text' name='userId'  className='form-control' placeholder='Enter UserId' pattern="^[A-Za-z]{5,29}$" onChange={this.handleSetuser} required></input>
             {show && !userId && <div className='help-block'><h6 style={{textAlign: 'center', color: 'black'}}><b>*userId is required</b></h6></div>}
             </div>  
             
             <div  className={'form-group'+ (show && !password ? 'has-error': '')}>
            <label  htmlFor='password'><h5 style={{textAlign: 'center', color: 'white'}}><b>Password:</b></h5></label>  <br></br> <input type='password' name='password' className='form-control' placeholder='Enter password'  onChange={this.handleSetpassword} required></input>
              {show&& userId && !password && <div className='help-block'><h6 style={{textAlign: 'center', color: 'black'}}><b>*Password is required</b></h6></div>}
              </div>
             <br></br>
             

             <div>
          
       
                 
             <button type="submit" className='btn btn-success' style={{marginLeft: "10px"}} onClick={this.handlesubmit} background-color='pink' color='blue'>Login</button>
             {loggingIn &&
                            <img src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA=="  alt='sucess'/>
                        }
            {/* {this.state.show ? <viewpage/>:''} */}
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <button className='btn btn-success' color='bule' style={{marginLeft: "10px"}} onClick={this.register}>Register</button>
          
                        </div>
                        
                
                           </form>
             
                           
            </div>
         
         </div>
       
        // </>
         
        );
        
    }}
/*function mapState(state){
   
    const{loggingIn}=state.authentication;
    
    return {loggingIn};
}
const actionCreators={
    login:userActions.login
}
const connedLoginPage=connect(mapState,actionCreators)(Login);*/
export default Login;