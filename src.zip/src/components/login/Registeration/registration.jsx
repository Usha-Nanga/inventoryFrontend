import React from 'react'
import { Button } from 'react-bootstrap';
import {toast} from 'react-toastify'
import {history} from '../history'
import 'react-toastify/dist/ReactToastify.css'
import LoginService from '../Service/LoginService'
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles.css'
toast.configure();
class Registration extends React.Component{
    constructor(props){
        super(props);
    this.state={
        userId:'',
        emailId:'',
        password:'',
        confirmPassword:'',
        contactNumber:'',
        type:'',
        show:false,
        vali:false,
    }
   
};
handleSetuser=(e)=>{
    this.setState({userId:(e.target.value)})
}
handleSetpassword=(e)=>{
    this.setState({password:e.target.value})
}
handleSetconfirmpassword=(e)=>{
    
    this.setState({confirmPassword:e.target.value})
    
}
handleContactNo=(e)=>{
    this.setState({contactNumber:e.target.value})
}
handletype=(e)=>{
    console.log(e.target.value);
    this.setState({
        type:e.target.value
    })
}
email=(e)=>{
    this.setState({emailId:e.target.value})
}
handlesubmit=()=>{
let data={userId:this.state.userId,emailId:this.state.emailId,password:this.state.password,confirmPassword:this.state.confirmPassword,contactNumber:this.state.contactNumber,type:this.state.type}
console.log('data=>'+JSON.stringify(data));

LoginService.register(data).then(res=>
    {
        console.log(res.data);
        
        toast.success("registration successfull",{position:toast.POSITION.TOP_CENTER,autoClose:false})
       history.push("/login");
    }).catch(res=>{
        console.log(res.data);
        toast.error("Enter correct data",{position:toast.POSITION.TOP_CENTER,autoClose:false})
        //history.push("/register");
    });
    history.push("/login");
//alert("userid"+this.state.userId);
}
checkuser=()=>{
    LoginService.byId(this.state.userId).then(res=>{
        if(res.data===false)
        {
            this.setState({vali:true});
        }else{
            this.setState({vali:false});
        }
    })
}
check=()=>{
    if(this.state.password!==this.state.confirmPassword)
    {
        this.setState({show:true});
       
toast.error("password must match",{position:toast.POSITION.TOP_CENTER,autoClose:false})

    }else{
        this.setState({show:false});
}
}
handlecancel=()=>{
    this.props.history.push('/login');
}
    render(){
        return(
<div>
<img src="https://www.chlsoftech.com/Content/product-eZ/images/inventory-banner.jpg" height="100%" width="100%" vspace="60" alt="summer cool"></img>
    <div className='id1'>
        <div className='dat'>
        <h4 style={{textAlign: 'center', color: 'white'}}>Registration Form</h4>
    {/* <h4>Registration Form</h4> */}
    <form className='register'>
        <div>
    <label htmlFor='userId'>UserId: </label>   <br></br><input type='text' name='userId'  className='form-control' placeholder='Enter UserId' pattern="^[A-Za-z]{5,29}$" onChange={this.handleSetuser} onBlur={this.checkuser} required></input>
    {this.state.vali===true?'*userId avaliable':''}
    </div>
    <div>
        <label htmlFor='emailId' >Email:</label>  <br></br><input type='email' name='emailId' className='form-control' onChange={this.email} required></input>
    </div>
    <div>
    <label htmlFor='password'>Password:</label>  <br></br> <input type='password' name='password' className='form-control' placeholder='Enter password'  onChange={this.handleSetpassword} required></input>
              
        </div> 
        <div>
    <label htmlFor='confirmPassword'>confirmPassword:</label>  <br></br> 
    <input type='password' name='confirmPassword' className='form-control' placeholder='Enter confirm password' 
         onChange={this.handleSetconfirmpassword} onBlur={this.check} required></input>
             {this.state.show===true?'*password must match':''}
        </div>    
            <div>
                <label htmlFor='contactNumber'>contactNumber:</label> <br></br>                   
                 <input type='text' name="contactNumber"  className='form-control' onChange={this.handleContactNo} required></input>  
            </div>
            <div>
                  <label htmlFor='type'>UserType:</label>   <br></br> 
              
            <select className='form-control' name="userType" onChange={this.handletype} value={this.state.type}>
          <option value="customer" >Customer</option>
          <option value="admin" >Admin</option>
         
        </select>
            </div>
            <br></br>
            <div className='lo'>
                <Button className='btn btn-success'  type="submit" onClick={this.handlesubmit}>Register</Button>
                &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;
                <Button className='btn btn-danger'  type="submit" onClick={this.handlecancel}>Cancel</Button>
            </div>
    </form>
    </div></div>
</div>
        );
    }
}
export default Registration