import React, { Component } from 'react'
import CustomerService from './services/CustomerService';
import InputGroup from 'react-bootstrap/InputGroup'
import './CreateCustomerComponent.css'
import Card from 'react-bootstrap/Card'
import {Button} from 'react-bootstrap'
import './Form.css';
import { FormErrors } from './FormErrors';
import Header from '../common/Header'

class CreateCustomerComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            customerId: this.props.match.params.id,
            customerName: '',
            customerNumber: '',
            customerAddress: '',
            customerEmail:'',
            customerStoreName:'',
            formErrors: {customerEmail: '',customerNumber:''},
            emailValid: false,
            phoneValid: false,
            formValid: false
        }
        this.changeCustomerNameHandler = this.changeCustomerNameHandler.bind(this);
        this.changeCustomerNumberHandler = this.changeCustomerNumberHandler.bind(this);
        this.changeCustomerAddressHandler = this.changeCustomerAddressHandler.bind(this);
        // this.changeCustomerEmailHandler = this.changeCustomerEmailHandler.bind(this);
        this.changeCustomerStoreNameHandler = this.changeCustomerStoreNameHandler.bind(this);
        this.saveOrUpdateCustomer = this.saveOrUpdateCustomer.bind(this);
    }

    
    handleUserInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        this.setState({[name]: value},
                      () => { this.validateField(name, value) });
      }
    
      validateField(fieldName, value) {
        let fieldValidationErrors = this.state.formErrors;
        let emailValid = this.state.emailValid;
        let phoneValid = this.state.phoneValid;
    
        switch(fieldName) {
          case 'customerEmail':
            emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
            fieldValidationErrors.customerEmail = emailValid ? '' : ' is invalid';
            break;
          case 'customerNumber':
            phoneValid = value.length >= 10;
            fieldValidationErrors.customerNumber = phoneValid ? '': ' should be a number with 10 digits';
            break;
          default:
            break;
        }
        this.setState({formErrors: fieldValidationErrors,
                        emailValid: emailValid,
                        phoneValid: phoneValid
                      }, this.validateForm);
      }
    
      validateForm() {
        this.setState({formValid: this.state.emailValid && this.state.phoneValid});
      }
    
      errorClass(error) {
        return(error.length === 0 ? '' : 'has-error');
      }
    saveOrUpdateCustomer = (e) => {
        e.preventDefault();
        let customer = {customerName: this.state.customerName, customerNumber: this.state.customerNumber, customerAddress: this.state.customerAddress, customerEmail: this.state.customerEmail, customerStoreName: this.state.customerStoreName};
        console.log('customer => ' + JSON.stringify(customer));

        // step 5
        if(this.state.customerId === '_add'){
            CustomerService.createCustomer(customer).then(res =>{
                this.props.history.push('/customer');
            });
        }else{
            CustomerService.updateCustomer(customer, this.state.customerId).then( res => {
                this.props.history.push('/customer');
            });
        }
    }
    
    changeCustomerNameHandler= (event) => {
        this.setState({customerName: event.target.value});
    }

    changeCustomerNumberHandler= (event) => {
        this.setState({customerNumber: event.target.value});
    }

    // changeCustomerEmailHandler= (event) => {
    //     this.setState({customerEmail: event.target.value});
    // }
    changeCustomerAddressHandler= (event) => {
        this.setState({customerAddress: event.target.value});
    }
    changeCustomerStoreNameHandler= (event) => {
        this.setState({customerStoreName: event.target.value});
    }

    cancel(){
        this.props.history.push('/customer');
    }
 
    componentDidMount(){

        // step 4
        if(this.state.customerId === '_add'){
            return
        }else{
            CustomerService.viewCustomerById(this.state.customerId).then( (res) =>{
                let customer = res.data;
                this.setState({customerName: customer.customerName,
                    customerNumber: customer.customerNumber,
                    customerAddress : customer.customerAddress,
                    customerEmail: customer.customerEmail,
                    customerStoreName: customer.customerStoreName
                });
            });
        }        
    }
    getTitle(){
        if(this.state.customerId === '_add'){
            return <h3 className="text-center">Add Customer</h3>
        }else{
            return <h3 className="text-center">Update Customer</h3>
        }
    }
    render() {
        return (
            // <>
            // <Header/>
            <div>
                <br></br>
                <Card border="primary" className ="card row-sm-6">
                                    <Card.Header>
                                      {
                                          this.getTitle()
                                        }
                                    </Card.Header>
                                    <Card.Body>
                                        <div>
                                        <form className="demoForm" onSubmit={this.saveOrUpdateCustomer}>
                                        <div className="panel panel-default">
                                            <FormErrors formErrors={this.state.formErrors} />
                                           </div>
                                        <div className = "form-group">
                                            <label> Customer Name: </label>
                                            <input placeholder="Customer Name" name="customerName" required className="form-control" 
                                                value={this.state.customerName} onChange={this.changeCustomerNameHandler}/>
                                        </div>
                                        <div className={`form-group ${this.errorClass(this.state.formErrors.customerNumber)}`}>
                                            
                                        <label htmlFor="tel">Customer Number</label>
                                            <InputGroup className="mb-3">
                                                <InputGroup.Prepend>
                                            <InputGroup.Text id="basic-addon1"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone" viewBox="0 0 16 16">
                                                <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.568 17.568 0 0 0 4.168 6.608 17.569 17.569 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.678.678 0 0 0-.58-.122l-2.19.547a1.745 1.745 0 0 1-1.657-.459L5.482 8.062a1.745 1.745 0 0 1-.46-1.657l.548-2.19a.678.678 0 0 0-.122-.58L3.654 1.328zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/>
                                                </svg></InputGroup.Text>
                                                 </InputGroup.Prepend>
                                                 <input type="tel"  required className="form-control" name="customerNumber" placeholder="number"  value={this.state.customerNumber} onChange={this.handleUserInput} onBlur={validatephoneno} />
                                                 </InputGroup>
                                         </div>
                                       
                                        <div className={`form-group ${this.errorClass(this.state.formErrors.customerEmail)}`}>
                                            <label htmlFor="email">Email </label>
                                         <InputGroup className="mb-3">
                                                <InputGroup.Prepend>
                                                <InputGroup.Text id="basic-addon1"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
                                                <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2zm13 2.383l-4.758 2.855L15 11.114v-5.73zm-.034 6.878L9.271 8.82 8 9.583 6.728 8.82l-5.694 3.44A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.739zM1 11.114l4.758-2.876L1 5.383v5.73z"/>
                                                </svg></InputGroup.Text>
                                                </InputGroup.Prepend>
                                                <input type="email" required className="form-control" name="customerEmail"
                                            placeholder="Email"
                                            value={this.state.customerEmail}
                                            onChange={this.handleUserInput} 
                                            />
                                            </InputGroup>
                                        </div>
                                           
                                        <div className = "form-group">
                                            <label> Address: </label>
                                                                       
                                            <input placeholder="Address" name="address" required className="form-control" 
                                                value={this.state.customerAddress} onChange={this.changeCustomerAddressHandler}/>
                                               
                                        </div>
                                        <div className = "form-group">
                                            <label> Store Name: </label>
                                            <input placeholder="Store Name" name="storeName" required className="form-control" 
                                                value={this.state.customerStoreName} onChange={this.changeCustomerStoreNameHandler}/>
                                        </div>

                                        <Button type="submit"  variant="outline-primary" ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16">
                                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                            <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/>
                                            </svg> Save</Button>
                                            <Button variant="outline-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                                                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                                            </svg> Cancel</Button>
                                    </form>    
                        </div>
                             {/* <br></br>
                            <br></br> */}
                            </Card.Body>
                         </Card>
                            
            </div>
        // </>
        )
    }
}

function validatephoneno(event) {

    const data = event.target.value;
    console.log("target", data);

    let regex = /^[0-9]+$/;
    let str = data;
    console.log(regex, str);

    if(regex.test(str) && str != "")
    {
        console.log("valid");
    }
    else
    {
        alert("Enter valid phone number, it should be an integer and cannot be blank!");
    }
}
export default CreateCustomerComponent
