import React, { Component } from 'react'
import ProductService from './services/ProductService'
import {Img} from 'react-image'
import {Button} from 'react-bootstrap'
import { FaRegTrashAlt, FaPlus } from "react-icons/fa";
import Header from '../common/Header'

export default class ListProductComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            productId: this.props.match.params.productId,
            products: []
        }
        this.createProduct = this.createProduct.bind(this);
        this.updateProduct = this.updateProduct.bind(this);
        this.deleteProduct = this.deleteProduct.bind(this);
        this.getProduct = this.getProduct.bind(this);
    }

    createProduct() {
        this.props.history.push('/add-product/_add');
    }

    updateProduct(productId) {
        this.props.history.push(`/update-product/${productId}`);
    }
    deleteProduct(productId) {
        ProductService.deleteProduct(productId).then(res => {
            this.setState({ products: this.state.products.filter(product => product.productId !== productId) });
        });
    }

    componentDidMount() {
        ProductService.getProducts().then((res) => {
            this.setState({ products: res.data });
        });
    }

    getProduct(productId) {
        this.props.history.push(`/get-product/${productId}`);
    }

    home(){
        this.props.history.push('/home');
    }

    render() {
        return (
            <>
                <Header />
                <div>
                    <h2 className="text-center">product List</h2>
                    <div className="row">
                        <button style={{marginLeft: "30px"}}  className="btn btn-primary" onClick={this.createProduct}> <FaPlus /> Product</button>
                        {/* <Button style={{marginLeft: "1100px"}} variant="outline-secondary" onClick={this.home.bind(this)}><svg width="2em" height="2em" viewBox="0 0 16 16" class="bi bi-house-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                   <path fill-rule="evenodd" d="M8 3.293l6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6zm5-.793V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
                   <path fill-rule="evenodd" d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z"/>
                   </svg> </Button> */}
                    </div>
                    
                    <br></br>
                    <div className="row">
                        <table className="table table-striped table-bordered md m-3">

                            <thead className="table-dark">
                                <tr>

                                    <th> product Name</th>
                                    <th> product Description</th>
                                    <th> product Price</th>
                                    <th> product Tag</th>
                                    <th> product Quantity</th>
                                    <th> product Size</th>
                                    <th> product Unit</th>
                                    <th> product Location</th>
                                    <th> product Photo</th>

                                    <th> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.products.map(
                                        product =>
                                            <tr key={product.productId}>

                                                

                                                <td> {product.productName} </td>
                                                <td> {product.productDescription}</td>
                                                <td> {product.productPrice}</td>
                                                <td> {product.productTag} </td>
                                                <td> {product.productQuantity} </td>
                                                <td> {product.productSize} </td>
                                                <td> {product.productUnit} </td>
                                                <td> {product.productLocation} </td>
                                                <td><img src={product.productPhoto} height="100" width="100" alt=""></img></td>

                                                <td>

                                                    <button onClick={() => this.updateProduct(product.productId)} className="btn btn-info">&#x270E;</button>
                                                    <button style={{marginLeft:"10px"}}onClick={() => this.deleteProduct(product.productId)} className="btn btn-danger"><FaRegTrashAlt /></button>
                                                    <button onClick={() => this.getProduct(product.productId)} className="btn btn-info">&#x2139;</button>

                                                </td>
                                            </tr>
                                    )
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
            </>
        )
    }
}