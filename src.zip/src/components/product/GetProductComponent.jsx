import React, { Component } from 'react'
import ProductService from './services/ProductService';

export default class GetProductComponent extends Component {

    constructor(props) {
        super(props)

        this.state = {
            productId: this.props.match.params.productId,
            product: {}
        }
    }

    componentDidMount(){
        ProductService.getProductById(this.state.productId).then( res => {
            this.setState({product: res.data});
            this.setState({productId:this.state.product.productId})
        })
    }
    cancel(){
        this.props.history.push(`/product`)
    }

    render() {
        return (
            <div>
            <br></br>
            <div className = "card col-md-6 offset-md-3">
                <h3 className = "text-center"> View Product Details</h3>
                <div className = "card-body">
                    <div className = "row">
                        <label> ProductName: </label>
                        <div> { this.state.product.productName }</div>
                    </div>
                    <div className ="row">
                        <label> ProductPrice: </label>
                        <div> { this.state.product.productPrice }</div>
                    </div>
                    <div className ="row">
                        <label> ProductDescription: </label>
                        <div> { this.state.product.productDescription }</div>
                    </div>
                    <div className ="row">
                        <label> ProductTag: </label>
                        <div> { this.state.product.productTag }</div>
                    </div>
                    <div className ="row">
                        <label> ProductQuantity: </label>
                        <div> { this.state.product.productQuantity }</div>
                    </div>
                    <div className ="row">
                        <label> ProductSize: </label>
                        <div> { this.state.product.productSize }</div>
                    </div>
                    <div className ="row">
                        <label> ProductUnit: </label>
                        <div> { this.state.product.productUnit }</div>
                    </div>
                    <div className ="row">
                        <label> ProductLocation: </label>
                        <div> { this.state.product.productLocation }</div>
                    </div>
                    <div className ="row">
                        <label> ProductPhoto: </label>
                        <div> { <img src={this.state.product.productPhoto} height="100" width="100" alt=""></img> }</div>
                    </div>

                    <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                    </div>

                </div>
            </div>
        )
    }
}