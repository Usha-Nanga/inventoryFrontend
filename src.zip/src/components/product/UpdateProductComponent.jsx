import React, { Component } from 'react'
import ProductService from './services/ProductService';
import Header from '../common/Header'

class UpdateProductComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            productId: this.props.match.params.productId,
            productName: '',
            productDescription: '',
            productPrice: '',
            productTag:'',
            productQuantity:'',
            productSize:'',
            productUnit:'',
            productLocation:''
        }
        this.changeProductNameHandler= this.changeProductNameHandler.bind(this);
        this.changeProductDescriptionHandler = this.changeProductDescriptionHandler.bind(this);
        this.changeProductPriceHandler = this.changeProductPriceHandler.bind(this);
        this.changeProductTagHandler = this.changeProductTagHandler.bind(this);
        this.changeProductQuantityHandler = this.changeProductQuantityHandler.bind(this);
        this.changeProductSizeHandler = this.changeProductSizeHandler.bind(this);
        this.changeProductUnitHandler = this.changeProductUnitHandler.bind(this);
        this.changeProductLocationHandler = this.changeProductLocationHandler.bind(this);
        this.updateProduct = this.updateProduct.bind(this);
    }

    componentDidMount(){
        ProductService.getProductById(this.state.productId).then( (res) =>{
            let product = res.data;
            this.setState({productName: product.productName,
                productDescription: product.productDescription,
                 productPrice : product.productPrice,
                 productQuantity:product.productQuantity,
                 productTag: product.productTag,
                 productSize:product.productSize,
                productUnit:product.productUnit,
                productLocation:product.productLocation,
                productPhoto:product.productPhoto
            });
            console.log("productId==",this.state.productId);
        });
    }

    updateProduct = (e) => {
        e.preventDefault();
        let product = {productId:this.state.productId, productName: this.state.productName,productDescription: this.state.productDescription, productPrice: this.state.productPrice, 
            productTag:this.state.productTag, productQuantity:this.state.productQuantity, productSize:this.state.productSize,productUnit:this.state.productUnit,
            productLocation:this.state.productLocation, productPhoto:this.state.productPhoto};
        console.log('product => ' + JSON.stringify(product));
        console.log('productId => ' + JSON.stringify(this.state.productId));
        ProductService.updateProduct(product, this.state.productId).then( res => {
            this.props.history.push('/product');
        });
    }
    changeProductNameHandler= (event) => {
        this.setState({productName: event.target.value});
    }

    changeProductDescriptionHandler= (event) => {
        this.setState({productDescription: event.target.value});
    }

    changeProductPriceHandler= (event) => {
        this.setState({productPrice: event.target.value});
    }

    changeProductTagHandler= (event) => {
        this.setState({productTag: event.target.value});
    }

    changeProductQuantityHandler= (event) => {
        this.setState({productQuantity: event.target.value});
    }
    changeProductSizeHandler= (event) => {
        this.setState({productSize: event.target.value});
    }
    changeProductUnitHandler= (event) => {
        this.setState({productUnit: event.target.value});
    }
    changeProductLocationHandler= (event) => {
        this.setState({productLocation: event.target.value});
    }
    changeProductPhotoHandler= (event) => {
        this.setState({productPhoto: event.target.value});
    }

    cancel(){
        this.props.history.push(`/product/${this.state.productId}`);
    }

    render() {
        return (
            <>
            <Header/>
            <div>
                 <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                <h3 className="text-center">Update Product</h3>
                                <div className = "card-body">
                                    <form>
                                    <div className = "form-group">
                                            <label> productName: </label>
                                            <input placeholder="productName" name="productName" className="form-control" 
                                                value={this.state.productName} onChange={this.changeProductNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label>Description </label>
                                            <input placeholder="productDescription" name="productDescription" className="form-control" 
                                                value={this.state.productDescription} onChange={this.changeProductDescriptionHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> productPrice </label>
                                            <input placeholder="product productPrice" name="productPrice" className="form-control" 
                                                value={this.state.productPrice} onChange={this.changeProductPriceHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> ProductTag </label>
                                            <input placeholder="product productTag" name="productTag" className="form-control" 
                                                value={this.state.productTag} onChange={this.changeProductTagHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> ProductQuantity </label>
                                            <input placeholder="product productQuantity" name="productQuantity" className="form-control" 
                                                value={this.state.productQuantity} onChange={this.changeProductQuantityHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> productSize </label>
                                            <input placeholder="productSize" name="productSize" className="form-control" 
                                                value={this.state.productSize} onChange={this.changeProductSizeHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> productUnit </label>
                                            <input placeholder="productUnit" name="productUnit" className="form-control" 
                                                value={this.state.productUnit} onChange={this.changeProductUnitHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> productLocation </label>
                                            <input placeholder="productLocation" name="productLocation" className="form-control" 
                                                value={this.state.productLocation} onChange={this.changeProductLocationHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> productPhoto </label>
                                            <input placeholder="productPhoto" name="productPhoto" className="form-control" 
                                                value={this.state.productPhoto} onChange={this.changeProductPhotoHandler}/>
                                        </div>



                                        <button className="btn btn-success" onClick={this.updateProduct}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
            </>
        )
    }
}

export default UpdateProductComponent