import axios from "axios";

const PRODUCT_API_BASE_URL = "http://localhost:8080/api/v1/product";

class ProductService {
  getProducts() {
    return axios.get(PRODUCT_API_BASE_URL +"/getAllProducts");
  }

  createProduct(product) {
    return axios.post(PRODUCT_API_BASE_URL +"/createProduct", product);
  }

  getProductById(productId) {
    return axios.get(PRODUCT_API_BASE_URL + "/getProductById/" + productId);
  }

  updateProduct(product, productId) {
    return axios.put(PRODUCT_API_BASE_URL + "/updateProduct/" + productId, product);
  }

  deleteProduct(productId) {
    return axios.delete(PRODUCT_API_BASE_URL + "/deleteProduct/" + productId);
  }
}

export default new ProductService();