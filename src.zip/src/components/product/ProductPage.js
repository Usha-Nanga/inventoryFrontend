import React from "react";

class ProductPage extends React.Component {
  render() {
    return <div>ProductPage</div>;
  }
}
export default ProductPage;
