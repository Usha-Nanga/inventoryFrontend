import React, { Component } from 'react'
import ProductService from './services/ProductService';
import Header from '../common/Header'

export default class CreateProductComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            
            productId: this.props.match.params.id,
            productName: '',
            productDescription: '',
            productPrice: '',
            productTag:'',
            productQuantity:'',
            productSize:'',
            productUnit:'',
            productLocation:'',
            productPhoto:'',
            categoryId: ''


        }
        this.changeproductNameHandler= this.changeproductNameHandler.bind(this);
        this.changeproductDescriptionHandler = this.changeproductDescriptionHandler.bind(this);
        this.changeproductPriceHandler = this.changeproductPriceHandler.bind(this);
        this.changeproductTagHandler = this.changeproductTagHandler.bind(this);
        this.changeproductQuantityHandler = this.changeproductQuantityHandler.bind(this);
        this.changeproductSizeHandler = this.changeproductSizeHandler.bind(this);
        this.changeproductUnitHandler = this.changeproductUnitHandler.bind(this);
        this.changeproductLocationHandler = this.changeproductLocationHandler.bind(this);
        this.changeproductPhotoHandler = this.changeproductPhotoHandler.bind(this);
        this.changecategoryIdHandler = this.changecategoryIdHandler.bind(this);
        this.saveProduct = this.saveProduct.bind(this);
    }

    saveProduct = (e) => {
        e.preventDefault();
        let product = {productName: this.state.productName, productDescription: this.state.productDescription, 
            productPrice: this.state.productPrice, productTag:this.state.productTag, productQuantity:this.state.productQuantity,
            productSize:this.state.productSize, productUnit:this.state.productUnit,productLocation:this.state.productLocation,
            productPhoto:this.state.productPhoto, categoryId: this.state.categoryId};
        console.log('product => ' + JSON.stringify(product));

        ProductService.createProduct(product).then(res =>{
            this.props.history.push(`/product/${this.state.categoryId}`);
        });
    }
    
    changeproductNameHandler= (event) => {
        this.setState({productName: event.target.value});
    }
    changeproductDescriptionHandler= (event) => {
        this.setState({productDescription: event.target.value});
    }
    changeproductPriceHandler= (event) => {
        this.setState({productPrice: event.target.value});
    }
    changeproductTagHandler= (event) => {
        this.setState({productTag: event.target.value});
    }
    changeproductQuantityHandler= (event) => {
        this.setState({productQuantity: event.target.value});
    }
    changeproductSizeHandler= (event) => {
        this.setState({productSize: event.target.value});
    }
    changeproductUnitHandler= (event) => {
        this.setState({productUnit: event.target.value});
    }
    changeproductLocationHandler= (event) => {
        this.setState({productLocation: event.target.value});
    }
    changeproductPhotoHandler= (event) => {
        this.setState({productPhoto: event.target.value});
    }
    changecategoryIdHandler= (event) => {
        this.setState({categoryId: event.target.value});
    }

    cancel(){
        this.props.history.push(`/product/${this.state.categoryId}`);
    }

    getTitle(){
        return <h3 className="text-center" style={{color: "red"}}>Add Product</h3>
    }
    render() {
        return (
            // <>
            // <Header/>
            <div>
                  <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                {
                                    this.getTitle()
                                }
                                <div className = "card-body">
                                    <form>
                                        <div className = "form-group">
                                            <label> productName: </label>
                                            <input placeholder="productName" name="productName" className="form-control" 
                                                value={this.state.productName} onChange={this.changeproductNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label>productDescription </label>
                                            <input placeholder="productDescription" name="productDescription" className="form-control" 
                                                value={this.state.productDescription} onChange={this.changeproductDescriptionHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> productPrice </label>
                                            <input placeholder="productPrice" name="productPrice" className="form-control" 
                                                value={this.state.productPrice} onChange={this.changeproductPriceHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> productTag </label>
                                            <input placeholder="productTag" name="productTag" className="form-control" 
                                                value={this.state.productTag} onChange={this.changeproductTagHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> productQuantity </label>
                                            <input placeholder="productQuantity" name="productQuantity" className="form-control" 
                                                value={this.state.productQuantity} onChange={this.changeproductQuantityHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> productSize </label>
                                            <input placeholder="productSize" name="productSize" className="form-control" 
                                                value={this.state.productSize} onChange={this.changeproductSizeHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> productUnit </label>
                                            <input placeholder="productUnit" name="productUnit" className="form-control" 
                                                value={this.state.productUnit} onChange={this.changeproductUnitHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> productLocation </label>
                                            <input placeholder="productLocation" name="productLocation" className="form-control" 
                                                value={this.state.productLocation} onChange={this.changeproductLocationHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> productPhoto </label>
                                            <input placeholder="productPhoto" name="productPhoto" className="form-control" 
                                                value={this.state.productPhoto} onChange={this.changeproductPhotoHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> categoryId </label>
                                            <input placeholder="categoryId" name="categoryId" className="form-control" 
                                                value={this.state.categoryId} onChange={this.changecategoryIdHandler}/>
                                        </div>

                                        <button className="btn btn-success" onClick={this.saveProduct}>&#x2713;Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>&#x2716;Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
            // </>
        )
    }
}