const TransactionReducer = (state= {transactions: [], list: [], deletetrans: [], addtrans: []}, action) => {
    switch(action.type){

        //case to view all transactions
        case 'VIEW_ALL_TRANSACTION_LIST': 
        state.transactions=action.payload;
        console.log('VIEW_ALL_TRANSACTION_LIST', state.transactions);
        return state;

        //case to view a single transaction using id
        case 'VIEW_A_TRANSACTION': 
        state.list=action.payload;
        console.log('VIEW_A_TRANSACTION', state.list);
        return state;

        //case to delete a transaction
        case 'DELETE_TRANSACTION': 
        state.deletetrans=action.payload;
        console.log('DELETE_TRANSACTION', state.deletetrans);
        return state;

        //case to add a transaction
        case 'ADD_TRANSACTION': 
        console.log("In Transaction Reducer",action.payload);
            state.addtrans.push(action.payload);
            return state;

        default:
            return state;

    
      
    }

}

export default TransactionReducer;