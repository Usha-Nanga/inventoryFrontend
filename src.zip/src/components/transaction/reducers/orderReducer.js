const OrderReducer = (state= {searchorder: [], searchallorders: [], deleteaorder: []}, action) => {
    switch(action.type){

        //case to view order
        case 'VIEW_A_ORDER': 
        state.searchorder=action.payload;
        console.log('VIEW_A_ORDER', state.searchorder);
        return state;


        
        //case to view all orders
        case 'VIEW_ALL_ORDER_LIST': 
        state.searchallorders=action.payload;
        console.log('VIEW_ALL_ORDER_LIST', state.searchallorders);
        return state;

        //case to delete a order
        case 'DELETE_ORDER': 
        state.deleteaorder=action.payload;
        console.log('DELETE_ORDER', state.deleteaorder);
        return state;



        default:
            return state;
     
    }

}
export default OrderReducer;