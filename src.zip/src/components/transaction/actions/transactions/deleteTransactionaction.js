import axios from 'axios';

const DeleteTransactionAction = (props) => {
    return async function (dispatch) {
        var err = null;
        var onLoad = 0;
        const axios = require('axios').default;
        const url = 'http://localhost:8080/api/v1/transactions/' + props;
        const serverResponse = await axios.delete(url) //await can only be used with async function....
            .then(response => dispatch({ type: 'DELETE_TRANSACTION', payload: response.data }))
            .catch(error => console.log(err = error));
        console.log(props);
        if (err !== null && props != undefined) {
            console.log("No Transaction Found");
            dispatch({ type: 'DELETE_TRANSACTION', payload: null });
        }
    }
}

export default DeleteTransactionAction;