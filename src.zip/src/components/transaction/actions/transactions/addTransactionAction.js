import axios from 'axios'


let AddTransactionAction = (addtrans) => {
console.log("In action : ",addtrans);

    return async function (dispatch) {
        const res = await axios.post(
            `http://localhost:8080/api/v1/transactions`,

                {
                    order: {"orderId": addtrans.order.ordID},
                    transactionDate: addtrans.transactionDate,
                    totalPrice: addtrans.totalPrice,  
                    gst: addtrans.gst,
                    paymentType: addtrans.paymentType,
                    paidAmount: addtrans.paidAmount, 
					dueAmount: addtrans.dueAmount
                   
                }, 
                { 
                    "Content-type": "application/json; charset=UTF-8"
                }
            );
         
          dispatch({type: "ADD_TRANSACTION", payload: res.data});
    }
}

export default AddTransactionAction;