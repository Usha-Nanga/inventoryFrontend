import axios from 'axios'

const ViewAllTransactionAction = ()=> {
    return async function(dispatch){
        var err = null;
        const axios = require('axios').default;
        const url = 'http://localhost:8080/api/v1/transactions';
        const serverResponse = await axios.get(url) //await can only be used with async function....
        .then(response => dispatch({type: 'VIEW_ALL_TRANSACTION_LIST', payload: response.data}))
        .catch(error => console.log(err=error));
        if(err!=null || serverResponse==null){
            console.log("Something went wrong while connecting to srver");
        }
    }
}

export default ViewAllTransactionAction;