class Order{
    constuctor(customerId, orderDate,deliveryDate, orderAmount, discountPercentage, customerId  ){
    this.orderDate=orderDate;
		this.deliveryDate = deliveryDate;
		this.orderAmount = orderAmount;
        this.discountPercentage=discountPercentage;
        this.customer={"custID":customerId};

    }

}