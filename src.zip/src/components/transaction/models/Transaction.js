class Transaction{
    constructor(orderId,transactionDate,totalPrice,gst,paymentType,paidAmount,dueAmount){
        this.transactionDate=transactionDate;
        this.totalPrice=totalPrice;
        this.gst=gst;
        this.paymentType=paymentType;
        this.paidAmount=paidAmount;
        this.dueAmount=dueAmount;
        this.order={"ordID":orderId};

    }
}
export default Transaction;