import { Navbar, Carousel, Jumbotron, Button, Nav, Card, Container, Row, Col } from 'react-bootstrap';


const HomeComponent = () => {
    return (
      <div>
  
  
        <Jumbotron style={{ backgroundColor: 'rgba(15,15,15,0.4)', filter: 'blur(10)' }}>
  
          <Row>
            <Col style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', color: 'white' }}>
              <h1><b>Welcome to Inventory Management System</b></h1>
              
  
            </Col>
          </Row>
        </Jumbotron>
        <div class="d-flex flex-column">
          <footer class="footer">
            <div style={{backgroundColor: 'rgba(15,15,15,0.4)'}}>
              <span><b style={{color: "white"}}>&copy; Content owned by the team of above mentioned individuals. Code available on</b></span>
              <a href="https://github.com/neetimishra98/Sprint3_InterviewTrackingSystem"> Git Hub Repository</a>
            </div>
          </footer>
        </div>
      </div>
    );
  }
  export default HomeComponent;
  
  

  