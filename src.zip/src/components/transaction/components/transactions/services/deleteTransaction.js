import { Form, Table, Jumbotron, Button, Modal, Alert } from 'react-bootstrap';

import { render } from '@testing-library/react';
import React, { useState } from 'react'

import { useDispatch, useSelector } from 'react-redux';
import DeleteTransactionAction from '../../../actions/transactions/deleteTransactionaction'

const DeleteTransaction = (props) => {

    var pathVar = null;
    let transMember = useSelector((state) => state.TransactionReducer.deletetrans);
    let dispatcher = useDispatch();
    React.useEffect(() => DeleteTransactionAction_Function(), [])
    const DeleteTransactionAction_Function = () => {
        dispatcher(DeleteTransactionAction(pathVar));
    }

    const handleSubmitDelete = (event) => {
        pathVar = document.getElementById("pathVariable").value;
        console.log("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", pathVar);
        dispatcher(DeleteTransactionAction(pathVar));
        renderDataTransactionDelete(transMember);
        console.log(pathVar);
        //alert("Transaction deleted Successfully !");
    }


    return (
        // All Final Operations and Functions
        <div style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
        }}>
            <Jumbotron style={{ width: 500 }}>
                <Form>
                    <Form.Group controlId="formGroupText">
                        <Form.Label for="pathVariable">Delete by valid Transaction ID</Form.Label>
                        <Form.Control id="pathVariable" type="text" placeholder="Transaction ID" onBlur={validateTransactionIdDelete}  />
                    </Form.Group>
                    <Button variant="dark" type="button" call onClick={handleSubmitDelete}>
                        Delete
                    </Button>
                    
                        <hr></hr>
                        {renderDataTransactionDelete(transMember)}
                </Form>
            </Jumbotron>
        </div>
    );


    //Alert
    function AlertTransNotFoundDelete() {
        const [show, setShow] = useState(true);
        console.log(show, setShow);
        if (show) {
          return (
            <Alert variant="danger" onClose={() => setShow(false)} dismissible>
              <Alert.Heading>Transaction Not Found</Alert.Heading>
              <p>
              Order with the mentioned transaction id was not found. Maybe you entered wrong id. Please check once!
              </p>
            </Alert>
          );
        }
        else{
            return (
                <div></div>
            );
        }

    }

    //validate Transaction ID
    function validateTransactionIdDelete(event) {

        const data = event.target.value;
        console.log("target", data);
    
        let regex = /^[0-9]+$/;
        let str = data;
        console.log(regex, str);
    
        if(regex.test(str) && str != "")
        {
            console.log("valid");
        }
        else
        {
            alert("Enter valid Transaction ID, it should be an integer and cannot be blank!");
        }
     }

    function renderDataTransactionDelete(transMember) {
        console.log("trans member dispatcher object returned from the server : ", transMember);
        

    if(transMember!==undefined && transMember!==null){
        return(
            <Table striped bordered hover size="sm">
            <thead>
                <tr>
                   
                    
                </tr>
            </thead>
            <tbody>
                <tr>
    
                   
                </tr>
            </tbody>
        </Table>
        );
    }
    if(transMember!==undefined && transMember===null){
        console.log("called the alert for tech");
        return(<AlertTransNotFoundDelete show="true"/>);
    }

}
}

export default DeleteTransaction;