import React, { useState } from 'react'
import { Form, Table, Jumbotron, Button, Alert } from 'react-bootstrap'

import { useDispatch, useSelector } from 'react-redux';
import ViewTransactionAction from '../../../actions/transactions/viewTransactionAction'

const ViewTransactionByID = (props) => {

    var translist = null;
    let member = useSelector(state => state.TransactionReducer.list);
    let dispatcher = useDispatch();
    React.useEffect(()=>ViewTransactionAction_Function(), [])
    const ViewTransactionAction_Function = () => {
            console.log(translist);
            dispatcher(ViewTransactionAction(translist));
    }
    
    const handleSubmit = (event) =>{ 
        translist = document.getElementById("tranid").value;
        dispatcher(ViewTransactionAction(translist));
       renderTableData(member);
    }

    return (
        // All Final Operations and Functions
        <div style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
          }}>
            <Jumbotron style={{width: 800}}>
                <Form>
                    <Form.Group controlId="formGroupText">
                        <Form.Label>View Transaction Using Transactionid</Form.Label>
                        <Form.Control id="tranid" type="text" placeholder="Transaction ID" onBlur={validateTransactionId} />
                        </Form.Group>
                    <Button variant="dark" type="button" call onClick={handleSubmit}>
                        Search
                    </Button>
                    <hr></hr>
                        {renderTableData(member)}
                </Form>
            </Jumbotron>
        </div>
    );

    //Alert
    function AlertMemberNotFoundTrans() {
        const [show, setShow] = useState(true);
        console.log(show, setShow);
        if (show) {
          return (
            <Alert variant="danger" onClose={() => setShow(false)} dismissible>
              <Alert.Heading>Transaction Not Found</Alert.Heading>
              <p>
              Order with the mentioned transaction id was not found. Maybe you entered wrong id. Please check once!
              </p>
            </Alert>
          );
        }
        else{
            return (
                <div></div>
            );
        }

    }

    //validate Transaction ID
    function validateTransactionId(event) {

        const data = event.target.value;
        console.log("target", data);
    
        let regex = /^[0-9]+$/;
        let str = data;
        console.log(regex, str);
    
        if(regex.test(str) && str != "")
        {
            console.log("valid");
        }
        else
        {
            alert("Enter valid Transaction ID, it should be an integer and cannot be blank!");
        }
     }
    

    function renderTableData(member) {   
        console.log("transaction dispatcher object returned from the server : ", member);
        if(member!==undefined && member!==null && member.length!==0){
            return(
                <Table striped bordered hover size="sm">
                    <thead>
                        <tr>
                            <th>Transaction ID</th> 
                            <th>Order ID</th>
                            <th>Transaction Date</th>
                            <th>Total Price</th>
                            <th>GST</th>
                            <th>Payment Type</th>
                            <th>Paid<br></br>Amount</th>
                            <th>Due<br></br>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>{member.data.transactionId}</td> 
                            <td>{member.data.order.orderId}</td>
                            <td>{member.data.transactionDate}</td>
                            <td>{member.data.totalPrice}</td>
                            <td>{member.data.gst}</td>
                            <td>{member.data.paymentType}</td>
                            <td>{member.data.paidAmount}</td>
                            <td>{member.data.dueAmount}</td>                            
                        </tr>
                        </tbody>
                </Table>
            );
        }

        if(member!==undefined && member===null){
            console.log("called the alert for tech");
            return(<AlertMemberNotFoundTrans show="true"/>);
        }
    }        

}

export default ViewTransactionByID;