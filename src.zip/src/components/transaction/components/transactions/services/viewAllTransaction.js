import React from 'react';
import { Form, Table, Jumbotron, Button } from 'react-bootstrap';
import { useSelector, useDispatch } from 'react-redux';
import ViewAllTransactionAction from '../../../actions/transactions/viewAllTransactionAction'

const ViewAllTransactions = (props) => {


    let transactionsList= useSelector((state)=>state.TransactionReducer.transactions);
    let dispatcher = useDispatch();
    React.useEffect(()=>TransactionsList(), [])
        const TransactionsList = () => {
            dispatcher(ViewAllTransactionAction());
        }

       
        console.log("TransactionsList: ", transactionsList);
        if (!Array.isArray(transactionsList)) {
            transactionsList = [];
            console.log("Set Transactions to blank array");
        }

        return (

            <div style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center"
            }}>
                <Jumbotron style={{ width: 800 }}>
                    <Form>
                        <Form.Group controlId="formGroupText">
                            <Form.Label>List of All Transactions</Form.Label>
                        </Form.Group>
                        <Table striped bordered hover size="sm">
                        <thead>
                             <tr>
                            <th>Transaction ID</th>  
                            <th>Order ID</th>
                            <th>Total Price</th>
                            <th>GST</th>
                            <th>Date</th>
                            <th>Payment Type</th>
                            <th>Paid Amount</th>
                            <th>Due Amount</th>
                        </tr>
                </thead>
                <hr></hr>
                    {renderData(transactionsList)}
           
            </Table>
            </Form>
            </Jumbotron>
        </div>
    
        );
    
    
    function renderData(transactionsList) {
        console.log("transactions dispatcher object returned from the server : ", transactionsList);
        return transactionsList.map((transaction, index) => {
            const Orderid = transaction.order.orderId;
            //const EmployeeName = panelmember.employeeEntity.name;
           // const { panelid, location, type } = panelmember //destructuring

/*
        if(transactions!==undefined) {
          return transactions.map((transaction,index) =>{ */
            const {transactionId,totalPrice,gst,transactionDate,paymentType,paidAmount,dueAmount} = transaction //destructuring
            return(
                        <tbody>
                            <tr>
                            <td>{transactionId}</td>     
                            <td>{Orderid}</td>
                            <td>{totalPrice}</td>
                            <td>{gst}</td>
                            <td>{transactionDate}</td>
                            <td>{paymentType}</td> 
                            <td>{paidAmount}</td>
                            <td>{dueAmount}</td>
                    </tr>
                    </tbody>
        )
    });
        }
    }
    
    export default ViewAllTransactions;