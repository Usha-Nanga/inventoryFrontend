import React from 'react';
import { Nav, Spinner, Dropdown, Navbar, NavDropdown, MenuItem, Form, Jumbotron, Tabs, ButtonToolbar, Button, Table, ButtonGroup, Row, Col, Grid, Panel, FormGroup, FormControl } from 'react-bootstrap';
import { useSelector, useDispatch } from 'react-redux';
import { useHistory } from "react-router-dom";

import AddTransactionAction from '../../../actions/transactions/addTransactionAction'
import Transaction from '../../../models/Transaction'
import ViewAllOrdersAction from '../../../actions/orders/viewAllOrdersAction'
    

    let dispatch;
    let history;
    let selectedordId;


    const AddTransaction  = (props) => {

        dispatch = useDispatch();
        history = useHistory();

        let ordList = useSelector(state => state.OrderReducer.searchallorders);
            console.log("ordList: ", ordList);
            React.useEffect(() => {
                orderList()
              }, []);
            
              const orderList = () => {
                dispatch(ViewAllOrdersAction())
              }
    
              if(!Array.isArray(ordList)){
                ordList = [];
                console.log("Set ordList to  blank array");
            } 

        
        return (
            // All Final Operations and Functions
    
            <div style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
               
            }}>
                <Jumbotron style={{ width: 800 }}>
                    <Form onSubmit={handleSubmit}>
                        <Form.Group controlId="formGroupText">
                            <Form.Label>Add A Transaction</Form.Label>
                        </Form.Group>

                        <Form.Group controlId="formBasicOrderID">
                           <Form.Label>Order ID </Form.Label>
                           <Form.Control as="select" id="order" name="order" onChange={handleChangeorder}>
                            {renderorders(ordList)}
                        </Form.Control>

                        </Form.Group>

    
                        <Form.Group controlId="formBasicTransactionDate">
                            <Form.Label>Transaction Date</Form.Label>
                            <Form.Control type="date" name="date" placeholder="Date of Transaction" id="date"/>
                        </Form.Group>
    
                        <Form.Group controlId="formBasicTotalPrice">
                            <Form.Label>Total Price</Form.Label>
                            <Form.Control type="text" id="tp" name="tp" onBlur={validateTotalPrice}/>
                        </Form.Group>
    
                        <Form.Group controlId="formBasicGst">
                            <Form.Label>GST </Form.Label>
                            <Form.Control type="text" id="gt" name="gt" onBlur={validateGST} />
                        </Form.Group>
    
                        <Form.Group controlId="formBasicPaymentType">
                            <Form.Label>Payment Type </Form.Label>
                            <Form.Control type="text" id="pt" name="pt" />
                        </Form.Group>

                        <Form.Group controlId="formBasicPaidAmount">
                            <Form.Label>Paid Amount </Form.Label>
                            <Form.Control type="text" id="pa" name="pa" onBlur={validatePaidAmt}/>
                        </Form.Group >

                        <Form.Group controlId="DueAmount">
                            <Form.Label>Due Amount </Form.Label>
                            <Form.Control type="text" id="da" name="da" onBlur={validateDueAmt}/>
                        </Form.Group>

                        <Form.Group>
                    <Button variant="dark" type="submit">CREATE</Button>
                    &nbsp; &nbsp;    
                    <Button variant="primary" type="reset">Reset </Button>
                    </Form.Group>
  
                    </Form>
                </Jumbotron>
            </div>
        );
    }

    
    //validate Transaction ID
    function validatePaidAmt(event) {

        const data = event.target.value;
        console.log("target", data);
    
        let regex = /^[0-9]+$/;
        let str = data;
        console.log(regex, str);
    
        if(regex.test(str) && str != "")
        {
            console.log("valid");
        }
        else
        {
            alert("Enter valid Paid Amount, it should be an integer and cannot be blank!");
        }
     }

     //validate Transaction ID
    function validateGST(event) {

        const data = event.target.value;
        console.log("target", data);
    
        let regex = /^[0-9]+$/;
        let str = data;
        console.log(regex, str);
    
        if(regex.test(str) && str != "")
        {
            console.log("valid");
        }
        else
        {
            alert("Enter valid GST , it should be an integer and cannot be blank!");
        }
     }


     //validate Transaction ID
    function validateTotalPrice(event) {

        const data = event.target.value;
        console.log("target", data);
    
        let regex = /^[0-9]+$/;
        let str = data;
        console.log(regex, str);
    
        if(regex.test(str) && str != "")
        {
            console.log("valid");
        }
        else
        {
            alert("Enter valid Total Price, it should be an integer and cannot be blank!");
        }
     }

    //validate Transaction ID
    function validateDueAmt(event) {

        const data = event.target.value;
        console.log("target", data);

        let regex = /^[0-9]+$/;
        let str = data;
        console.log(regex, str);

        if(regex.test(str) && str != "")
        {
            console.log("valid");
        }
        else
        {
            alert("Enter valid Due Amount, it should be an integer and cannot be blank!");
        }
    }

    


    function handleChangeorder(event) {
        // console.log("panellllllllll", panList);
            selectedordId = event.target.value
         console.log("selected order member: "+ selectedordId);
     }

     function renderorders(ordList){
        console.log("panelList: ", ordList);
        //console.log("deptList[0].deptId: ", deptList[0].deptId);
        return ordList.map((ord, index) => {
           const { orderId } = ord //destructuring //candidte id 
           return (
            <option key={orderId} value={orderId}>{orderId}</option>
           )
        })
     };


    function handleSubmit(event) {
        event.preventDefault();
        const data = new FormData(event.target);
        const transactionDate = data.get('date');
        const selectedordId=data.get('order');
        const totalPrice=data.get('tp');
        const gst=data.get('gt');
        const paymentType=data.get('pt');
        const paidAmount=data.get('pa');
        const dueAmount=data.get('da');
        if(totalPrice==='' ||totalPrice===null) {
            alert("Total Price should not be blank");
            return;
        }
        if(transactionDate==='' ||transactionDate===null) {
            alert("Transaction Date should not be blank");
            return;
        }
        if(gst==='' ||gst===null) {
            alert("GST should not be blank");
            return;
        }
        if(paymentType==='' ||paymentType===null) {
            alert("Payment Type should not be blank");
            return;
        }
        if(paidAmount==='' ||paidAmount===null) {
            alert("Paid Amount should not be blank");
            return;
        }
        if(dueAmount==='' ||dueAmount===null) {
            alert("Due Amount should not be blank");
            return;
        }
        if(selectedordId==='' ||selectedordId===null) {
            alert("Order ID should not be blank");
            return;
        }

        const transactionObj = new Transaction(selectedordId, transactionDate, totalPrice, gst, paymentType, paidAmount, dueAmount );
        console.log("Transaction Object : ",transactionObj);
        dispatch(AddTransactionAction(transactionObj));
        history.push('/transactions');
        alert("Transaction added Successfully !");
    }
    
    export default AddTransaction;