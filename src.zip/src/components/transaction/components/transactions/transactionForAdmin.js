import ViewAllTransactions from './services/viewAllTransaction'
import ViewTransactionByID from './services/viewTransaction'
import DeleteTransaction from './services/deleteTransaction'
import AddTransaction from './services/addTransaction'

import { Row, Col, table, Accordion, Card, Button, Container } from 'react-bootstrap'
import Header from '../../../common/Header'


const TransactionForAdmin = () => {


    return (
        <>
        <Header/>
        <div>

            <Container className="mr-5">
                <card>
                    {/* All underlying operations from services */}
                    <Accordion>

                        <table className="marginLeft">
                            <Col className="align-items-center">
                                <Row>
                                    <Accordion.Toggle as={Button} variant="dark" eventKey="0">
                                        <center><h2><b>View All Transactions</b></h2></center>
                                    </Accordion.Toggle>

                                    <Accordion.Collapse eventKey="0">
                                        <Card.Body class="bg-custom"><ViewAllTransactions></ViewAllTransactions></Card.Body>
                                    </Accordion.Collapse>
                                </Row>


                                <Row>
                                    <Accordion.Toggle as={Button} variant="dark" eventKey="1">
                                        <center><h2><b>View Transaction By ID</b></h2></center>
                                    </Accordion.Toggle>

                                    <Accordion.Collapse eventKey="1">
                                        <Card.Body class="bg-custom"><ViewTransactionByID></ViewTransactionByID></Card.Body>
                                    </Accordion.Collapse>
                                </Row>


                                <Row>
                                    <Accordion.Toggle as={Button} variant="dark" eventKey="2">
                                        <center><h2><b>Add a Transaction</b></h2></center>
                                    </Accordion.Toggle>

                                    <Accordion.Collapse eventKey="2">
                                        <Card.Body class="bg-custom"><AddTransaction></AddTransaction></Card.Body>
                                    </Accordion.Collapse>
                                </Row>

                            

                                <Row>
                                    <Accordion.Toggle as={Button} variant="dark" eventKey="3">
                                        <center><h2><b>Delete Transaction</b></h2></center>
                                    </Accordion.Toggle>

                                    <Accordion.Collapse eventKey="3">
                                        <Card.Body class="bg-custom"><DeleteTransaction></DeleteTransaction></Card.Body>
                                    </Accordion.Collapse>
                                </Row>
                                

                             

                            </Col>
                        </table>
                    </Accordion>
                </card>
            </Container>
        </div>
        </>
    );
}

export default TransactionForAdmin;