import { Route, Link, Switch } from 'react-router-dom';
//Bootstrap
import {Tab,Tabs,Jumbotron,Container, Navbar, Nav, NavDropdown } from 'react-bootstrap';
import { Button } from 'react-bootstrap';
import TransactionComponent from './transactions/transactionForAdmin'

const HomeTransactionComponent = () => {
    return (
        <div>
            
                        
           
                    <TransactionComponent></TransactionComponent>
            
                    
                
           
        </div>
    );
}



export default HomeTransactionComponent;