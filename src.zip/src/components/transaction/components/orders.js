import OrderForAdmin from './orders/orderForAdmin' 

const OrderComponent = () => {
    return (
        <div style={{ backgroundColor: "navy" }}>
            <br></br>
            <h1 style={{ color: "white" }}><b><i>Orders Services</i></b></h1>
            <br></br>

            <Tabs defaultActiveKey="Homem" id="uncontrolled-tab-example" variant="pills">
                <Tab eventKey="OrderView" title="Orders" >
                    <OrderForAdmin></OrderForAdmin>
                </Tab>

                
            </Tabs>
        </div>
    );
}




export default OrderComponent;


export default TransactionComponent;