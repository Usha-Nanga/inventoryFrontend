
import { Route, Link, Switch } from 'react-router-dom';
//Bootstrap
import {Tab,Tabs,Jumbotron,Container, Navbar, Nav, NavDropdown } from 'react-bootstrap';
import { Button } from 'react-bootstrap';
import OrderComponent from './orders/orderForAdmin'

const HomeOrderComponent = () => {
    return (
        <div>
            
                        
           
                    <OrderComponent></OrderComponent>
            
                    
                
           
        </div>
    );
}



export default HomeOrderComponent;