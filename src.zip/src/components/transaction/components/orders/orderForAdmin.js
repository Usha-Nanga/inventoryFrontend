import { Row, Col, table, Accordion, Card, Button, Container } from 'react-bootstrap'

import SearchOrder from './searchOrder'
import ViewAllOrders from './viewAllOrders'
import DeleteOrder from './deleteOrder'


const OrderForAdmin = () => {


    return (
        <div>

            <Container className="mr-5">
                <card>
                    {/* All underlying operations from services */}
                    <Accordion>

                        <table className="marginLeft">
                            <Col className="align-items-center">
                                <Row>
                                    <Accordion.Toggle as={Button} variant="dark" eventKey="9">
                                        <center><h2><b>View Order</b></h2></center>
                                    </Accordion.Toggle>

                                    <Accordion.Collapse eventKey="9">
                                        <Card.Body class="bg-custom"><SearchOrder></SearchOrder></Card.Body>
                                    </Accordion.Collapse>
                                </Row>

                                <Row>
                                    <Accordion.Toggle as={Button} variant="dark" eventKey="10">
                                        <center><h2><b>View All Orders</b></h2></center>
                                    </Accordion.Toggle>

                                    <Accordion.Collapse eventKey="10">
                                        <Card.Body class="bg-custom"><ViewAllOrders></ViewAllOrders></Card.Body>
                                    </Accordion.Collapse>
                                </Row>

                                <Row>
                                    <Accordion.Toggle as={Button} variant="dark" eventKey="11">
                                        <center><h2><b>Delete a Order</b></h2></center>
                                    </Accordion.Toggle>

                                    <Accordion.Collapse eventKey="11">
                                        <Card.Body class="bg-custom"><DeleteOrder></DeleteOrder></Card.Body>
                                    </Accordion.Collapse>
                                </Row>


                                </Col>
                        </table>
                    </Accordion>
                </card>
            </Container>
        </div>
    );
}

export default OrderForAdmin;