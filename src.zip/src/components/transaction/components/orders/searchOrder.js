import React, { useState } from 'react'
import { Form, Table, Jumbotron, Button, Alert } from 'react-bootstrap'

import { useDispatch, useSelector } from 'react-redux';
//import ViewTransactionAction from '../../../actions/transactions/viewTransactionAction'
import SearchOrdersAction from '../../actions/orders/searchOrdersAction'

const SearchOrder = (props) => {

    var orderlist = null;
    let memberl = useSelector(state => state.OrderReducer.searchorder);
    let dispatcher = useDispatch();
    React.useEffect(()=>SearchOrdersAction_Function(), [])
    const SearchOrdersAction_Function = () => {
            console.log(orderlist);
            dispatcher(SearchOrdersAction(orderlist));
    }
    
    const handleSubmit = (event) =>{ 
        orderlist = document.getElementById("ordid").value;
        dispatcher(SearchOrdersAction(orderlist));
        renderTableDataOrder(memberl);
    }

    return (
        // All Final Operations and Functions
        <div style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
          }}>
            <Jumbotron style={{width: 800}}>
                <Form>
                    <Form.Group controlId="formGroupText">
                        <Form.Label>View Order Using Order</Form.Label>
                        <Form.Control id="ordid" type="text" placeholder="Order ID" />
                        </Form.Group>
                    <Button variant="dark" type="button" call onClick={handleSubmit}>
                        Search
                    </Button>
                    <hr></hr>
                        {renderTableDataOrder(memberl)}
                </Form>
            </Jumbotron>
        </div>
    );

    //Alert
    function AlertMemberNotFoundOrder() {
        const [show, setShow] = useState(true);
        console.log(show, setShow);
        if (show) {
          return (
            <Alert variant="danger" onClose={() => setShow(false)} dismissible>
              <Alert.Heading>Order Not Found</Alert.Heading>
              <p>
              Order with the mentioned transaction id was not found. Maybe you entered wrong id. Please check once!
              </p>
            </Alert>
          );
        }
        else{
            return (
                <div></div>
            );
        }

    }
    function renderTableDataOrder(memberl) {   
        console.log("transaction dispatcher object returned from the server : ", memberl);
        if(memberl!==undefined && memberl!==null && memberl.length!==0){
            return(
                <Table striped bordered hover size="sm">
                    <thead>
                        <tr> 
                            <th>Order ID</th>
                            <th>Customer ID</th>
                            <th>Order Date</th>
                            <th>Delivery Date</th>
                            <th>Order Amount</th>
                            <th>Discount %</th>
                            </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>{memberl.data.orderId}</td> 
                            <td>{memberl.data.customer.customerId}</td>
                            <td>{memberl.data.orderDate}</td>
                            <td>{memberl.data.deliveryDate}</td>
                            <td>{memberl.data.orderAmount}</td>
                            <td>{memberl.data.discountPercentage}</td>
                        </tr>
                        </tbody>
                </Table>
            );
        }

        if(memberl!==undefined && memberl===null){
            console.log("called the alert for tech");
            return(<AlertMemberNotFoundOrder show="true"/>);
        }
    }        

}

export default SearchOrder;