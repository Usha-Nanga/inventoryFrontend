import React from 'react';
import { Form, Table, Jumbotron, Button } from 'react-bootstrap';
import { useSelector, useDispatch } from 'react-redux';
//import ViewAllTransactionAction from '../../../actions/transactions/viewAllTransactionAction'
import ViewAllOrdersAction from '../../actions/orders/viewAllOrdersAction'

const ViewAllOrders = (props) => {


    let ordList= useSelector((state)=>state.OrderReducer.searchallorders);
    let dispatcher = useDispatch();
    React.useEffect(()=>OrdeList(), [])
        const OrdeList = () => {
            dispatcher(ViewAllOrdersAction());
        }

       
        console.log("OrdersList: ", ordList);
        if (!Array.isArray(ordList)) {
            ordList = [];
            console.log("Set Orders to blank array");
        }

        return (

            <div style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center"
            }}>
                <Jumbotron style={{ width: 800 }}>
                    <Form>
                        <Form.Group controlId="formGroupText">
                            <Form.Label>List of All Orders</Form.Label>
                        </Form.Group>
                        <Table striped bordered hover size="sm">
                        <thead>
                             <tr>
                                <th>Order ID</th>
                                <th>Customer ID</th>
                                <th>Order Date</th>
                                <th>Delivery Date</th>
                                <th>Order Amount</th>
                                <th>Discount %</th>
                        </tr>
                </thead>
                <hr></hr>
                    {renderDataForAllOrders(ordList)}
           
            </Table>
            </Form>
            </Jumbotron>
        </div>
    
        );
    
    
    function renderDataForAllOrders(ordList) {
        console.log("orders dispatcher object returned from the server : ", ordList);
        if(ordList!==undefined) {
        return ordList.map((ord, index) => {
            const Customerid = ord.customer.customerId;
            //const EmployeeName = panelmember.employeeEntity.name;
           // const { panelid, location, type } = panelmember //destructuring

/*
        if(transactions!==undefined) {
          return transactions.map((transaction,index) =>{ */
            const {orderId,orderDate,deliveryDate,orderAmount,discountPercentage} = ord //destructuring
            return(
                        <tbody>
                            <tr>
                            <td>{orderId}</td> 
                            <td>{Customerid}</td>
                            <td>{orderDate}</td>
                            <td>{deliveryDate}</td>
                            <td>{orderAmount}</td>
                            <td>{discountPercentage}</td>
                    </tr>
                    </tbody>
        )
    });
        }
    }
}
    
    export default ViewAllOrders;