import TransactionForAdmin from './transactions/transactionForAdmin'

const TransactionComponent = () => {
    return (
        <div style={{ backgroundColor: "navy" }}>
            <br></br>
            <h1 style={{ color: "white" }}><b><i>Transaction Services</i></b></h1>
            <br></br>

            <Tabs defaultActiveKey="Home" id="uncontrolled-tab-example" variant="pills">
                <Tab eventKey="TransactionView" title="Transaction" >
                    <TransactionForAdmin></TransactionForAdmin>
                </Tab>

                
            </Tabs>
        </div>
    );
}




export default TransactionComponent;