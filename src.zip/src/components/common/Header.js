import React from "react";
import { NavLink } from "react-router-dom";
// import "./Header.css";

const Header = () => {
  const activeStyle = { backgroundColor: "doggerblue" };
  return (
    <nav className="navbar bg-info rounded mb-5 p-3">
      {/* <nav className="navbar navbar-light" style="background-color: #9863e7;"> */}
      <div className="nav">
        <div
          className="navbar font-weight-bold text-black h5"
          style={{ fontFamily: "Georgia" }}
        >
          Inventory Management
        </div>
        <NavLink
          className="btn font-weight-bold text-black px-4 mx-3"
          exact
          to="/home"
          activeStyle={activeStyle}
        >
          Home
        </NavLink>

        <NavLink
          className="btn font-weight-bold text-black px-4 mx-3"
          to="/customer"
          activeStyle={activeStyle}
        >
          Customer
        </NavLink>

        <NavLink
          className="btn font-weight-bold text-black px-4 mx-3"
          to="/product"
          activeStyle={activeStyle}
        >
          Product
        </NavLink>

        <NavLink
          className="btn font-weight-bold text-black px-4 mx-3"
          to="/category"
          activeStyle={activeStyle}
        >
          Category
        </NavLink>

        <NavLink
          className="btn font-weight-bold text-black px-4 mx-3"
          to="/order"
          activeStyle={activeStyle}
        >
          Order
        </NavLink>

        <NavLink
          className="btn font-weight-bold text-black px-4 mx-3"
          to="/transaction"
          activeStyle={activeStyle}
        >
          Transaction
        </NavLink>

        <NavLink
          className="btn font-weight-bold text-black px-4 mx-3"
          to="/login"
          activeStyle={activeStyle}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-power" viewBox="0 0 16 16">
  <path d="M7.5 1v7h1V1h-1z"/>
  <path d="M3 8.812a4.999 4.999 0 0 1 2.578-4.375l-.485-.874A6 6 0 1 0 11 3.616l-.501.865A5 5 0 1 1 3 8.812z"/>
</svg>
        </NavLink>
      </div>
    </nav>
  );
};

export default Header;
