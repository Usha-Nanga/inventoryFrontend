import React from "react";

class CategoryPage extends React.Component {
  render() {
    return <div>CategoryPage</div>;
  }
}
export default CategoryPage;
