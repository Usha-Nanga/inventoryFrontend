import React, { Component } from 'react'
import CategoryService from './services/CategoryService';


class CreateCategoryComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            categoryId: this.props.match.params.id,
           // categoryId: '',
            categoryName: '',
            categoryDescription: ''
        }
      //  this.changeCategoryIdHandler = this.changeCategoryIdHandler.bind(this);
        this.changeCategoryNameHandler = this.changeCategoryNameHandler.bind(this);
        this.changeCategoryDescriptionHandler = this.changeCategoryDescriptionHandler.bind(this);
        this.saveOrUpdateCategory = this.saveOrUpdateCategory.bind(this);
    }

    // step 3
    componentDidMount(){

        // step 4
        if(this.state.categoryId === '_add'){
            return
        }else{
            CategoryService.viewCategoryById(this.state.categoryId).then( (res) =>{
                let category = res.data;
                this.setState({//categoryId: category.categoryId,
                    categoryName: category.categoryName,
                    categoryDescription : category.categoryDescription
                });
            });
        }        
    }
    saveOrUpdateCategory = (e) => {
        e.preventDefault();
        let category = {categoryName: this.state.categoryName, categoryDescription: this.state.categoryDescription};
        console.log('category => ' + JSON.stringify(category));

        // step 5
        if(this.state.categoryId === '_add'){
            CategoryService.createCategory(category).then(res =>{
                this.props.history.push('/category');
            });
        }else{
            CategoryService.updateCategory(category, this.state.categoryId).then( res => {
                this.props.history.push('/category');
            });
        }
    }
    
   

    changeCategoryNameHandler= (event) => {
        this.setState({categoryName: event.target.value});
    }

    changeCategoryDescriptionHandler= (event) => {
        this.setState({categoryDescription: event.target.value});
    }

    cancel(){
        this.props.history.push('/category');
    }

    getTitle(){
        if(this.state.categoryId === '_add'){
            return <h3 className="text-center">Add Category</h3>
        }else{
            return <h3 className="text-center">Update Category</h3>
        }
    }
    render() {
        return (
        
            
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                {
                                    this.getTitle()
                                }
                                <div className = "card-body">
                                    <form>
                                    

                                        <div className = "form-group">
                                            <label> Category Name: </label>
                                            <input placeholder="Category Name" name="categoryName" className="form-control" 
                                                value={this.state.categoryName} onChange={this.changeCategoryNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Category Description: </label>
                                            <input placeholder="Category Description" name="categoryDescription" className="form-control" 
                                                value={this.state.categoryDescription} onChange={this.changeCategoryDescriptionHandler}/>
                                        </div>

                                        <button className="btn btn-success" onClick={this.saveOrUpdateCategory}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
            
        )
    }
}

export default CreateCategoryComponent