import React, { Component } from 'react'
import CategoryService from './services/CategoryService';


class UpdateCategoryComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            categoryId: '',
            categoryName: '',
            categoryDescription: ''
        }
        this.changeCategoryIdHandler = this.changeCategoryIdHandler.bind(this);
        this.changeCategoryNameHandler = this.changeCategoryNameHandler.bind(this);
        this.changeCategoryDescriptionHandler = this.changeCategoryDescriptionHandler.bind(this);
        this.updateCategory = this.updateCategory.bind(this);
    }

    componentDidMount(){
        CategoryService.getCategoryById(this.state.id).then( (res) =>{
            let category = res.data;
            this.setState({categoryId: category.categoryId,
                categoryName: category.categoryName,
                categoryDescription : category.categoryDescription
            });
        });
    }

    updateCategory = (e) => {
        e.preventDefault();
        let category = {categoryId: this.state.categoryId, categoryName: this.state.categoryName, categoryDescription: this.state.categoryDescription};
        console.log('category => ' + JSON.stringify(category));
        console.log('id => ' + JSON.stringify(this.state.id));
        CategoryService.updateCategory(category, this.state.id).then( res => {
            this.props.history.push('/category');
        });
    }
    
    changeCategoryIdHandler= (event) => {
        this.setState({categoryId: event.target.value});
    }

    changeCategoryNameHandler= (event) => {
        this.setState({categoryName: event.target.value});
    }

    changeCategoryDescriptionHandler= (event) => {
        this.setState({categoryDescription: event.target.value});
    }

    cancel(){
        this.props.history.push('/category');
    }

    render() {
        return (
            
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                <h3 className="text-center">Update Category</h3>
                                <div className = "card-body">
                                    <form>
                                        <div className = "form-group">
                                            <label> Category Id: </label>
                                            <input placeholder="Category Id" name="categoryId" className="form-control" 
                                                value={this.state.categoryId} onChange={this.changeCategoryIdHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Category Name: </label>
                                            <input placeholder="Category Name" name="categoryName" className="form-control" 
                                                value={this.state.categoryName} onChange={this.changeCategoryNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Category Description: </label>
                                            <input placeholder="Category Description" name="categoryDescription" className="form-control" 
                                                value={this.state.categoryDescription} onChange={this.changecategoryDescriptionHandler}/>
                                        </div>

                                        <button className="btn btn-success" onClick={this.updateCategory}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        
        )
    }
}

export default UpdateCategoryComponent