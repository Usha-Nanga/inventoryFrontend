import React, { Component } from 'react'
import CategoryService from './services/CategoryService'
import Header from '../common/Header'
import {Button} from 'react-bootstrap'


class ListCategoryComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                categories: []
        }
        this.addCategory = this.addCategory.bind(this);
        this.editCategory = this.editCategory.bind(this);
        this.deleteCategory = this.deleteCategory.bind(this);
    }
    home(){
        this.props.history.push('/home');
    }

    deleteCategory(categoryId){
        CategoryService.deleteCategory(categoryId).then( res => {
            this.setState({categories: this.state.categories.filter(category => category.categoryId !== categoryId)});
        });
    }
    viewCategory(categoryId){
        this.props.history.push(`/view-category/${categoryId}`);
    }
    editCategory(categoryId){
        this.props.history.push(`/add-category/${categoryId}`);
    }

    componentDidMount(){
        CategoryService.viewAllCategories().then((res) => {
            this.setState({ categories: res.data});
        });
    }

    addCategory(){
        this.props.history.push('/add-category/_add');
    }

    render() {
        return (
            <>
            <Header />
            <div>
                 <h2 className="text-center">Categories List</h2>
                 <div className = "row">
                    <button style={{marginLeft: "30px"}}className="btn btn-primary" onClick={this.addCategory}> Add Category</button>
                    {/* <Button style={{marginLeft: "1100px"}} variant="outline-secondary" onClick={this.home.bind(this)}><svg width="2em" height="2em" viewBox="0 0 16 16" class="bi bi-house-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                   <path fill-rule="evenodd" d="M8 3.293l6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6zm5-.793V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
                   <path fill-rule="evenodd" d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z"/>
                   </svg> </Button> */}
                 </div>
                 
                 <br></br>
                 <div className = "row">
                        <table className = "table table-striped table-bordered md m-4">

                            <thead className="table-dark">
                                <tr>
                                
                                    <th> Category Name</th>
                                    <th> Category Description</th>
                                    <th> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.categories.map(
                                        category => 
                                        <tr key = {category.categoryId}>
                                            
                                             <td> {category.categoryName}</td>
                                             <td> {category.categoryDescription}</td>
                                             <td>
                                                 <button onClick={ () => this.editCategory(category.categoryId)} className="btn btn-info">Update </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.deleteCategory(category.categoryId)} className="btn btn-danger">Delete </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.viewCategory(category.categoryId)} className="btn btn-info">View </button>
                                             </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>

                 </div>

            </div>
            </>
        )
    }
}

export default ListCategoryComponent