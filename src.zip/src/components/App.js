import React from "react";
import { Route, Switch } from "react-router-dom";
import LoginPage from "./login/LoginPage";
import Login from "./login/Login/Login";
import Registration from "./login/Registeration/registration";
import ListCustomerComponent from "./customer/ListCustomerComponent";
import CreateCustomerComponent from "./customer/CreateCustomerComponent";
import PageNotFound from "./PageNotFound";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "./App.css";

// import Home from "./components"
import ListOrderComponent from "./order/ListOrderComponent";
import CreateOrderComponent from "./order/CreateOrderComponent";
import ListProductComponent from "./product/ListProductComponent";
import CreateProductComponent from "./product/CreateProductComponent";
import UpdateProductComponent from "./product/UpdateProductComponent";
import GetProductComponent from "./product/GetProductComponent";
import HomeTransactionComponent from "./transaction/components/hometransaction";
import ListCategoryComponent from "./category/ListCategoryComponent";
import CreateCategoryComponent from "./category/CreateCategoryComponent";
import ViewCategoryComponent from "./category/ViewCategoryComponent";
import HomeComponent from "./transaction/components/home";

//background-repeat: no-repeat;
//background-size: cover;
function App() {
  return (
    <div className="container-fluid" style={{ fontFamily: "Lucida Console" }}>
      <Switch>
        <Route exact path="/" component={Login}></Route>
        <Route path="/register" component={Registration}></Route>
        <Route exact path="/login" component={Login}></Route>
        <Route exact path="/home" component={LoginPage} />
        
        <Route path="/customer" component={ListCustomerComponent} />
        <Route
          path="/add-customer/:id"
          component={CreateCustomerComponent}
        ></Route>
        <Route path="/product" component={ListProductComponent}></Route>
        <Route path="/add-product/:productId" component={CreateProductComponent}></Route>
        <Route path="/update-product/:productId" component={UpdateProductComponent}></Route>
        <Route path="/get-product/:productId" exact component={GetProductComponent}></Route>
        <Route path="/order" component={ListOrderComponent} />
        <Route path="/add-order/:id" component={CreateOrderComponent}></Route>
        <Route path="/category" component={ListCategoryComponent} />

        <Route
          path="/add-category/:id"
          component={CreateCategoryComponent}
        ></Route>
        <Route
          path="/view-category/:id"
          component={ViewCategoryComponent}
        ></Route>
        <Route path="/transaction" component={HomeTransactionComponent} />
        <Route component={HomeTransactionComponent} />
      </Switch>
      <ToastContainer autoClose={3000} hideProgressBar />
    </div>
  );
}

export default App;
