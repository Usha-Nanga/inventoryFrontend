import React, { Component } from 'react'
import OrderService from './services/OrderService';
import Card from 'react-bootstrap/Card'
import {Button} from 'react-bootstrap'
import './Form.css';
import { FormErrors } from './FormErrors';
import Header from '../common/Header'

class CreateOrderComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            orderId: this.props.match.params.id,
            orderDate: '',
            orderAmount: '',
            deliveryDate:'',
            products:'',
            customer:'',
            formErrors: {orderDate: '',deliveryDate:''},
            orderDateValid: false,
            deliveryDateValid: false,
            formValid: false
        }
        this.changeOrderDateHandler = this.changeOrderDateHandler.bind(this);
        this.changeOrderAmountHandler = this.changeOrderAmountHandler.bind(this);
        this.changeProductsHandler = this.changeProductsHandler.bind(this);
        this.changeCustomerHandler = this.changeCustomerHandler.bind(this);
        this.changeDeliveryDateHandler = this.changeDeliveryDateHandler.bind(this);
        this.saveOrUpdateOrder = this.saveOrUpdateOrder.bind(this);
    }

    
    handleUserInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        this.setState({[name]: value},
                      () => { this.validateField(name, value) });
      }
    
      validateField(fieldName, value) {
        let fieldValidationErrors = this.state.formErrors;
        let orderDateValid = this.state.orderDateValid;
        let deliveryDateValid = this.state.deliveryDateValid;
    
        switch(fieldName) {
          case 'orderDate':
            orderDateValid = value.match();
            fieldValidationErrors.orderDate = orderDateValid ? '' : ' is invalid';
            break;
          case 'deliveryDate':
            deliveryDateValid = value.length >= 10;
            fieldValidationErrors.deliveryDate = deliveryDateValid ? '': ' ';
            break;
          default:
            break;
        }
        this.setState({formErrors: fieldValidationErrors,
                        orderDateValid: orderDateValid,
                        deliveryDateValid: deliveryDateValid
                      }, this.validateForm);
      }
    
      validateForm() {
        this.setState({formValid: this.state.orderDateValid && this.state.deliveryDateValid});
      }
    
      errorClass(error) {
        return(error.length === 0 ? '' : 'has-error');
      }
    saveOrUpdateOrder = (e) => {
        e.preventDefault();
        let order = {customer: parseInt(this.state.customer), orderDate: this.state.orderDate, orderAmount: this.state.orderAmount, deliveryDate: this.state.deliveryDate, products: this.state.products};
        console.log('order => ' + JSON.stringify(order));

        // step 5
        if(this.state.orderId === '_add'){
            OrderService.createOrder(order).then(res =>{
                this.props.history.push('/home');
            });
        }else{
            OrderService.updateOrder(order, this.state.orderId).then( res => {
                this.props.history.push('/home');
            });
        }
    }
    
    changeOrderDateHandler= (event) => {
        this.setState({orderDate: event.target.value});
    }

    changeOrderAmountHandler= (event) => {
        this.setState({orderAmount: event.target.value});
    }

    // changeCustomerEmailHandler= (event) => {
    //     this.setState({customerEmail: event.target.value});
    // }
    changeDeliveryDateHandler= (event) => {
        this.setState({deliveryDate: event.target.value});
    }
    changeProductsHandler= (event) => {
        this.setState({products: event.target.value});
    }
    changeCustomerHandler= (event) => {
        this.setState({customer: event.target.value});
    }

    cancel(){
        this.props.history.push('/order');
    }
 
    componentDidMount(){

        // step 4
        if(this.state.orderId === '_add'){
            return
        }else{
            OrderService.viewOrderById(this.state.orderId).then( (res) =>{
                let order = res.data;
                this.setState({orderDate: order.orderDate,
                    orderAmount: order.orderAmount,
                    deliveryDate : order.deliveryDate,
                    customer: order.customer,
                    products: order.products
                });
            });
        }        
    }
    getTitle(){
        if(this.state.orderId === '_add'){
            return <h3 className="text-center">Add Order</h3>
        }else{
            return <h3 className="text-center">Update Order</h3>
        }
    }
    render() {
        return (
            <>
            <Header/>
            <div>
                <br></br>
                <Card border="primary" className ="card row-sm-6">
                                    <Card.Header>
                                      {
                                          this.getTitle()
                                        }
                                    </Card.Header>
                                    <Card.Body>
                                        <div>
                                        <form className="demoForm" onSubmit={this.saveOrUpdateOrder}>
                                        <div className="panel panel-default">
                                            <FormErrors formErrors={this.state.formErrors} />
                                           </div>
                                        <div className = "form-group">
                                            <label> Order Amount: </label>
                                            <input placeholder="Order Amount" name="orderAmount" required className="form-control" 
                                                value={this.state.orderAmount} onChange={this.changeOrderAmountHandler}/>
                                        </div>

                                        <div className={`form-group ${this.errorClass(this.state.formErrors.orderDate)}`}>
                                            
                                        <label htmlFor="orderDate">Order Date</label>
                                                 <input className="form-control" name="orderDate" placeholder="Order Date"  value={this.state.orderDate} onChange={this.handleUserInput} />
                                         </div>
                                       
                                        <div className={`form-group ${this.errorClass(this.state.formErrors.deliveryDate)}`}>
                                            <label htmlFor="deliveryDate">Delivery Date </label>
                                                <input required className="form-control" name="deliveryDate"
                                            placeholder="Delivery Date"
                                            value={this.state.deliveryDate}
                                            onChange={this.handleUserInput} 
                                            />
                                        </div>
                                           
                                        <div className = "form-group">
                                            <label> Products Id: </label>
                                                                       
                                            <input placeholder="Products" name="products" required className="form-control" 
                                                value={this.state.products} onChange={this.changeProductsHandler}/>
                                               
                                        </div>
                                        <div className = "form-group">
                                            <label>  Customer Id: </label>
                                            <input placeholder="Customer" name="customer" required className="form-control" 
                                                value={this.state.changeCustomerHandler} onChange={this.changeCustomerHandler}/>
                                        </div>

                                        <Button type="submit"  variant="outline-primary" ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16">
                                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                            <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/>
                                            </svg> Save</Button>
                                            <Button variant="outline-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                                                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                                            </svg> Cancel</Button>
                                    </form>    
                        </div>
                             {/* <br></br>
                            <br></br> */}
                            </Card.Body>
                         </Card>
                            
            </div>
        </>
        )
    }
}

export default CreateOrderComponent
