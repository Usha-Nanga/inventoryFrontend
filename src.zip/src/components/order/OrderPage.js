import React from "react";

class OrderPage extends React.Component {
  render() {
    return <div>OrderPage</div>;
  }
}
export default OrderPage;
