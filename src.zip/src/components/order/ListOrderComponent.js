import React, { Component } from "react";
import OrderService from "./services/OrderService";
import Table from "react-bootstrap/Table";
import { Button } from "react-bootstrap";
import Header from "../common/Header";

class ListOrderComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      orders: [],
    };
    this.addOrder = this.addOrder.bind(this);
    this.editOrder = this.editOrder.bind(this);
    this.deleteOrder = this.deleteOrder.bind(this);
  }

  deleteOrder(orderId) {
    OrderService.deleteOrder(orderId).then((res) => {
      this.setState({
        orders: this.state.orders.filter((order) => order.orderId !== orderId),
      });
    });
  }

  editOrder(orderId) {
    this.props.history.push(`/add-order/${orderId}`);
  }

  componentDidMount() {
    OrderService.viewAllOrders().then((res) => {
      this.setState({ orders: res.data });
    });
  }

  addOrder() {
    this.props.history.push("/add-order/_add");
  }
  home() {
    this.props.history.push("/home");
  }

  render() {
    return (
      <>
        <Header />
        <div className="container-fluid">
          <h2 className="text-center">Orders List</h2>
          <div className="row">
            <Button variant="outline-primary" onClick={this.addOrder}>
              {" "}
              <svg
                width="2em"
                height="2em"
                viewBox="0 0 16 16"
                class="bi bi-person-plus-fill"
                fill="currentColor"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fill-rule="evenodd"
                  d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm7.5-3a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"
                />
              </svg>
            </Button>
            {/* <Button
              style={{ marginLeft: "1200px" }}
              variant="outline-secondary"
              onClick={this.home.bind(this)}
            >
              <svg
                width="2em"
                height="2em"
                viewBox="0 0 16 16"
                class="bi bi-house-fill"
                fill="currentColor"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fill-rule="evenodd"
                  d="M8 3.293l6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6zm5-.793V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"
                />
                <path
                  fill-rule="evenodd"
                  d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z"
                />
              </svg>{" "}
            </Button> */}
          </div>
          <br></br>
          <div className="row">
            <Table striped bordered hover size="md">
              <thead className="table-dark">
                <tr>
                  <th> Order Id</th>
                  <th> Customer Id</th>
                  {/* <th> Products </th> */}
                  <th> Order Date</th>
                  <th> Order Amount</th>
                  <th> Delivery Date</th>
                  <th> Actions</th>
                </tr>
              </thead>
              <tbody>
                {this.state.orders.map((order) => (
                  <tr key={order.orderId}>
                    <td className="table-secondary"> {order.orderId} </td>
                    <td className="table-secondary">
                      {" "}
                      {order.customer.customerId}{" "}
                    </td>
                    {/* <td className="table-secondary">View Products</td> */}
                    <td className="table-secondary"> {order.orderDate}</td>
                    <td className="table-secondary"> {order.orderAmount}</td>
                    <td className="table-secondary"> {order.deliveryDate}</td>
                    <td className="table-secondary">
                      <Button
                        variant="outline-info"
                        onClick={() => this.editOrder(order.orderId)}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          fill="currentColor"
                          class="bi bi-pencil-square"
                          viewBox="0 0 16 16"
                        >
                          <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                          <path
                            fill-rule="evenodd"
                            d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"
                          />
                        </svg>
                      </Button>
                      <Button
                        variant="outline-danger"
                        style={{ marginLeft: "10px" }}
                        onClick={() => this.deleteOrder(order.orderId)}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          fill="currentColor"
                          class="bi bi-trash"
                          viewBox="0 0 16 16"
                        >
                          <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                          <path
                            fill-rule="evenodd"
                            d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"
                          />
                        </svg>
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </div>
      </>
    );
  }
}

export default ListOrderComponent;
